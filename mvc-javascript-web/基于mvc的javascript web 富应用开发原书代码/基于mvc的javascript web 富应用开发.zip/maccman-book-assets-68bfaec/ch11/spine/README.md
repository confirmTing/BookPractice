# Spine

__Spine is a lightwork framework for building JavaScript web applications.__ Spine gives you a MVC structure and then gets out of your way,  allowing you to concentrate on the fun stuff, building awesome web applications. 

Spine is tiny, the library comes in at around 500 lines of JavaScript, that's about 2K minified & compressed. However, it's not about size, it's how you use it, and Spine certainly packs a punch! 

For documentation, usage, and examples, see: [http://maccman.github.com/spine](http://maccman.github.com/spine)